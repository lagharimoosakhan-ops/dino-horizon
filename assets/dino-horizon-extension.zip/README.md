# DINO: HORIZON — Chrome Extension

The classic Chrome T-Rex runner, reimagined in 3D.

## Install (Developer mode)
1. Unzip this folder.
2. Open `chrome://extensions` (or `edge://extensions` in Edge).
3. Turn on **Developer mode**.
4. Select **Load unpacked** and choose the unzipped folder.
5. Pin the dino icon in the toolbar.

## Play
- Click the toolbar icon or press **Alt+Shift+D**
- **Space / ↑** jump · **← → / A D** change lane · **M** mute · swipe/tap on touch screens
- Works fully offline. High score is saved locally.

Built by Muhammad Moosa Laghari.
